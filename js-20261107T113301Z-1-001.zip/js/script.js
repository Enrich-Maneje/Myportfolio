// app.js: your first JavaScript program
// One statement = one instruction, ending in ;
console.log("Welcome to KapeTayo!");
console.log(2 + 3);
console.log("2" + 3);
console.log(typeof 160);
console.log(typeof "Spanish Latte");
/* alert("Hi!") shows a pop-up box;
console.log() writes here, in DevTools (F12) */
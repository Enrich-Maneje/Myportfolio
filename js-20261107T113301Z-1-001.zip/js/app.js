// const: a value that never changes
const SHOP = "KapeTayo";
let DELIVERY_FEE = 79;
// let: a value that can change
let cups = 3;
cups = cups + 2;
DELIVERY_FEE = DELIVERY_FEE + 21;
// var: the old way (function-scoped), avoid
var promo = "BREWDAY";
console.log(SHOP, "order:", cups, "cups");
console.log("Delivery fee:", DELIVERY_FEE);
console.log("Promo code:", promo);

